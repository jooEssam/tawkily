const express = require('express');
const router = express.Router();
const db = require('../database');
const { isAuthenticated } = require('../middleware/auth');

router.get('/', isAuthenticated, (req, res) => {
  const { client_name, archive_number, type_id, status, lawyer_id, letter } = req.query;
  let q = `SELECT p.*, pt.name as type_name, u.name as last_user_name, pc.name as category_name, l.name as location_name FROM powers p LEFT JOIN power_types pt ON p.type_id=pt.id LEFT JOIN users u ON p.last_user_id=u.id LEFT JOIN power_categories pc ON p.category_id=pc.id LEFT JOIN locations l ON p.location_id=l.id WHERE 1=1`;
  let params = [];
  if (client_name) { q += ' AND p.client_name LIKE ?'; params.push('%'+client_name+'%'); }
  if (archive_number) { q += ' AND p.archive_number LIKE ?'; params.push('%'+archive_number+'%'); }
  if (type_id) { q += ' AND p.type_id=?'; params.push(type_id); }
  if (status) { q += ' AND p.status=?'; params.push(status); }
  if (lawyer_id && req.session.user.role==='admin') { q += ' AND p.last_user_id=?'; params.push(lawyer_id); }
  if (letter) { q += ' AND p.client_name LIKE ?'; params.push(letter+'%'); }
  if (req.session.user.role==='lawyer') { q += ' AND (p.status="متاح" OR p.last_user_id=?)'; params.push(req.session.user.id); }
  q += ' ORDER BY p.created_at DESC';
  db.all(q, params, (err, powers) => {
    db.all('SELECT * FROM power_types ORDER BY name', [], (err, types) => {
      db.all('SELECT * FROM users WHERE role="lawyer" AND status="active" ORDER BY name', [], (err, lawyers) => {
        db.all('SELECT * FROM power_categories ORDER BY name', [], (err, categories) => {
          res.render('lawyer/search', { title: 'البحث المتقدم', powers: powers||[], types: types||[], lawyers: lawyers||[], categories: categories||[], query: req.query });
        });
      });
    });
  });
});

module.exports = router;
