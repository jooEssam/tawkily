const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../database');
const { isAuthenticated, isAdmin } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/dashboard', isAuthenticated, isAdmin, (req, res) => {
  const stats = {};
  db.get('SELECT COUNT(*) as c FROM powers', [], (err, row) => {
    stats.totalPowers = row ? row.c : 0;
    db.get("SELECT COUNT(*) as c FROM powers WHERE status='متاح'", [], (err, row) => {
      stats.availablePowers = row ? row.c : 0;
      db.get("SELECT COUNT(*) as c FROM powers WHERE status='مع زميل'", [], (err, row) => {
        stats.borrowedPowers = row ? row.c : 0;
        db.get("SELECT COUNT(*) as c FROM powers WHERE category='حفظ'", [], (err, row) => {
          stats.savedPowers = row ? row.c : 0;
          db.get("SELECT COUNT(*) as c FROM powers WHERE category='متداول'", [], (err, row) => {
            stats.circulatedPowers = row ? row.c : 0;
            db.get('SELECT COUNT(*) as c FROM users WHERE role="lawyer"', [], (err, row) => {
              stats.totalLawyers = row ? row.c : 0;
              db.get('SELECT COUNT(*) as c FROM power_types', [], (err, row) => {
                stats.totalTypes = row ? row.c : 0;
                db.get("SELECT COUNT(*) as c FROM power_transactions WHERE date(created_at)=date('now')", [], (err, row) => {
                  stats.todayTransactions = row ? row.c : 0;
                  db.all(`SELECT pt.name, COUNT(p.id) as count FROM power_types pt LEFT JOIN powers p ON pt.id=p.type_id GROUP BY pt.id`, [], (err, typeStats) => {
                    db.all(`SELECT al.*, u.name as user_name FROM activity_logs al LEFT JOIN users u ON al.user_id=u.id ORDER BY al.created_at DESC LIMIT 10`, [], (err, activities) => {
                      db.all(`SELECT p.*, u.name as lawyer_name, pt.name as type_name, julianday('now')-julianday(t.checkout_at) as days FROM powers p JOIN power_transactions t ON p.id=t.power_id JOIN users u ON t.user_id=u.id JOIN power_types pt ON p.type_id=pt.id WHERE p.status='مع زميل' AND t.return_at IS NULL AND julianday('now')-julianday(t.checkout_at)>7`, [], (err, overdue) => {
                        res.render('admin/dashboard', { title: 'لوحة تحكم الإدارة', stats, typeStats: typeStats||[], activities: activities||[], overdue: overdue||[] });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});

router.get('/users', isAuthenticated, isAdmin, (req, res) => {
  db.all('SELECT * FROM users WHERE role="lawyer" ORDER BY created_at DESC', [], (err, users) => {
    res.render('admin/users', { title: 'إدارة المحامين', users: users||[] });
  });
});

router.post('/users', isAuthenticated, isAdmin, (req, res) => {
  const { name, email, password, phone } = req.body;
  const hash = bcrypt.hashSync(password, 10);
  db.run('INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, ?)',
    [name, email, hash, phone, 'lawyer'], function(err) {
      if (err) req.flash('error', 'البريد مستخدم مسبقاً');
      else {
        req.flash('success', 'تم إضافة المحامي');
        db.run(`INSERT INTO activity_logs (user_id, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?)`,
          [req.session.user.id, 'إضافة محامي', 'user', this.lastID, name]);
      }
      res.redirect('/admin/users');
    });
});

router.post('/users/:id/edit', isAuthenticated, isAdmin, (req, res) => {
  const { name, email, phone, status } = req.body;
  db.run('UPDATE users SET name=?, email=?, phone=?, status=? WHERE id=?',
    [name, email, phone, status, req.params.id], (err) => {
      if (err) req.flash('error', 'خطأ');
      else req.flash('success', 'تم التحديث');
      res.redirect('/admin/users');
    });
});

router.post('/users/:id/delete', isAuthenticated, isAdmin, (req, res) => {
  db.run('DELETE FROM users WHERE id=? AND role="lawyer"', [req.params.id], (err) => {
    if (err) req.flash('error', 'لا يمكن الحذف');
    else req.flash('success', 'تم الحذف');
    res.redirect('/admin/users');
  });
});

router.get('/power-types', isAuthenticated, isAdmin, (req, res) => {
  db.all('SELECT * FROM power_types ORDER BY name', [], (err, types) => {
    res.render('admin/power-types', { title: 'أنواع التوكيلات', types: types||[] });
  });
});

router.post('/power-types', isAuthenticated, isAdmin, (req, res) => {
  db.run('INSERT INTO power_types (name) VALUES (?)', [req.body.name], (err) => {
    if (err) req.flash('error', 'النوع موجود');
    else req.flash('success', 'تم الإضافة');
    res.redirect('/admin/power-types');
  });
});

router.post('/power-types/:id/delete', isAuthenticated, isAdmin, (req, res) => {
  db.run('DELETE FROM power_types WHERE id=?', [req.params.id], (err) => {
    if (err) req.flash('error', 'لا يمكن الحذف');
    else req.flash('success', 'تم الحذف');
    res.redirect('/admin/power-types');
  });
});

router.get('/power-categories', isAuthenticated, isAdmin, (req, res) => {
  db.all('SELECT * FROM power_categories ORDER BY name', [], (err, categories) => {
    res.render('admin/power-categories', { title: 'تصنيفات التوكيلات', categories: categories||[] });
  });
});

router.post('/power-categories', isAuthenticated, isAdmin, (req, res) => {
  db.run('INSERT INTO power_categories (name) VALUES (?)', [req.body.name], (err) => {
    if (err) req.flash('error', 'التصنيف موجود');
    else req.flash('success', 'تم إضافة التصنيف');
    res.redirect('/admin/power-categories');
  });
});

router.post('/power-categories/:id/delete', isAuthenticated, isAdmin, (req, res) => {
  db.run('DELETE FROM power_categories WHERE id=?', [req.params.id], (err) => {
    if (err) req.flash('error', 'لا يمكن الحذف');
    else req.flash('success', 'تم الحذف');
    res.redirect('/admin/power-categories');
  });
});

// Locations management
router.get('/locations', isAuthenticated, isAdmin, (req, res) => {
  db.all('SELECT * FROM locations ORDER BY name', [], (err, locations) => {
    res.render('admin/locations', { title: 'أماكن التوكيلات', locations: locations||[] });
  });
});

router.post('/locations', isAuthenticated, isAdmin, (req, res) => {
  db.run('INSERT INTO locations (name, description) VALUES (?, ?)', [req.body.name, req.body.description], (err) => {
    if (err) req.flash('error', 'المكان موجود');
    else req.flash('success', 'تم إضافة المكان');
    res.redirect('/admin/locations');
  });
});

router.post('/locations/:id/delete', isAuthenticated, isAdmin, (req, res) => {
  db.run('DELETE FROM locations WHERE id=?', [req.params.id], (err) => {
    if (err) req.flash('error', 'لا يمكن الحذف');
    else req.flash('success', 'تم الحذف');
    res.redirect('/admin/locations');
  });
});

// Borrowed powers page with alert button
router.get('/borrowed-powers', isAuthenticated, isAdmin, (req, res) => {
  db.all(`SELECT p.*, u.name as lawyer_name, pt.name as type_name, t.checkout_at, julianday('now')-julianday(t.checkout_at) as days 
          FROM powers p JOIN power_transactions t ON p.id=t.power_id JOIN users u ON t.user_id=u.id 
          JOIN power_types pt ON p.type_id=pt.id WHERE p.status='مع زميل' AND t.return_at IS NULL ORDER BY t.checkout_at DESC`, [], (err, powers) => {
    res.render('admin/borrowed-powers', { title: 'التوكيلات مع الزملاء', powers: powers||[] });
  });
});

router.get('/all-powers', isAuthenticated, isAdmin, (req, res) => {
  const { letter, date_from, date_to, category_id } = req.query;
  let q = `SELECT p.*, pt.name as type_name, u.name as last_user_name, pc.name as category_name, l.name as location_name FROM powers p LEFT JOIN power_types pt ON p.type_id=pt.id LEFT JOIN users u ON p.last_user_id=u.id LEFT JOIN power_categories pc ON p.category_id=pc.id LEFT JOIN locations l ON p.location_id=l.id WHERE 1=1`;
  let params = [];
  if (letter) { q += ' AND p.client_name LIKE ?'; params.push(letter + '%'); }
  if (date_from) { q += ' AND date(p.created_at)>=?'; params.push(date_from); }
  if (date_to) { q += ' AND date(p.created_at)<=?'; params.push(date_to); }
  if (category_id) { q += ' AND p.category_id=?'; params.push(category_id); }
  q += ' ORDER BY p.created_at DESC';
  db.all(q, params, (err, powers) => {
    db.all('SELECT * FROM power_categories ORDER BY name', [], (err, categories) => {
      res.render('admin/all-powers', { title: 'جميع التوكيلات', powers: powers||[], categories: categories||[], query: req.query });
    });
  });
});

router.get('/activity-log', isAuthenticated, isAdmin, (req, res) => {
  db.all(`SELECT al.*, u.name as user_name FROM activity_logs al LEFT JOIN users u ON al.user_id=u.id ORDER BY al.created_at DESC LIMIT 200`, [], (err, logs) => {
    res.render('admin/activity-log', { title: 'سجل النشاطات', logs: logs||[] });
  });
});

router.get('/settings', isAuthenticated, isAdmin, (req, res) => {
  db.all('SELECT * FROM settings', [], (err, settings) => {
    const s = {};
    (settings||[]).forEach(x => s[x.key] = x.value);
    res.render('admin/settings', { title: 'إعدادات النظام', settings: s });
  });
});

router.post('/settings', isAuthenticated, isAdmin, upload.single('logo'), (req, res) => {
  const { system_name, primary_color } = req.body;
  const logo = req.file ? '/uploads/logos/' + req.file.filename : null;
  const update = (k, v) => new Promise((resolve, reject) => {
    if (!v) return resolve();
    db.run('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)', [k, v], (err) => err ? reject(err) : resolve());
  });
  Promise.all([update('system_name', system_name), update('primary_color', primary_color), update('logo', logo)])
    .then(() => { req.flash('success', 'تم الحفظ'); res.redirect('/admin/settings'); })
    .catch(() => { req.flash('error', 'خطأ'); res.redirect('/admin/settings'); });
});

// Admin Alert - Send reminder to lawyer
router.post('/send-alert/:powerId', isAuthenticated, isAdmin, (req, res) => {
  const { message } = req.body;
  const powerId = req.params.powerId;
  db.get('SELECT * FROM powers WHERE id=?', [powerId], (err, power) => {
    if (!power || !power.last_user_id) { req.flash('error', 'لا يوجد محامي'); return res.redirect('back'); }
    db.run(`INSERT INTO admin_alerts (power_id, user_id, message, sent_by) VALUES (?, ?, ?, ?)`,
      [powerId, power.last_user_id, message, req.session.user.id], (err) => {
        if (err) req.flash('error', 'خطأ');
        else {
          req.flash('success', 'تم إرسال التنبيه');
          db.run(`INSERT INTO notifications (user_id, title, message, sound_type) VALUES (?, ?, ?, ?)`,
            [power.last_user_id, 'تنبيه من الإدارة', message, 'alert']);
        }
        res.redirect('back');
      });
  });
});

module.exports = router;
