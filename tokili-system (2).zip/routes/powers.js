const express = require('express');
const router = express.Router();
const db = require('../database');
const { isAuthenticated, isAdmin } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/add', isAuthenticated, isAdmin, (req, res) => {
  db.all('SELECT * FROM power_types ORDER BY name', [], (err, types) => {
    db.all('SELECT * FROM power_categories ORDER BY name', [], (err, categories) => {
      db.all('SELECT * FROM locations ORDER BY name', [], (err, locations) => {
        res.render('powers/add', { title: 'إضافة توكيل', types: types||[], categories: categories||[], locations: locations||[] });
      });
    });
  });
});

router.post('/add', isAuthenticated, isAdmin, upload.single('pdf_file'), (req, res) => {
  const { client_name, archive_number, type_id, category_id, category, location_id, location, notes } = req.body;
  const pdf = req.file ? '/uploads/powers/' + req.file.filename : null;
  db.run(`INSERT INTO powers (client_name, archive_number, type_id, category_id, category, location_id, location, pdf_file, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [client_name, archive_number, type_id, category_id, category, location_id, location, pdf, notes, req.session.user.id], function(err) {
      if (err) { req.flash('error', 'رقم الفهرس مستخدم'); return res.redirect('/powers/add'); }
      req.flash('success', 'تم الإضافة');
      db.run(`INSERT INTO activity_logs (user_id, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?)`,
        [req.session.user.id, 'إضافة توكيل', 'power', this.lastID, client_name]);
      db.all('SELECT id FROM users WHERE role="lawyer" AND status="active"', [], (err, lawyers) => {
        lawyers.forEach(l => db.run(`INSERT INTO notifications (user_id, title, message, sound_type) VALUES (?, ?, ?, ?)`,
          [l.id, 'توكيل جديد', `تم إضافة: ${client_name} - ${archive_number}`, 'add']));
      });
      res.redirect('/admin/all-powers');
    });
});

router.get('/:id', isAuthenticated, (req, res) => {
  db.get(`SELECT p.*, pt.name as type_name, u.name as last_user_name, creator.name as creator_name, pc.name as category_name, l.name as location_name FROM powers p LEFT JOIN power_types pt ON p.type_id=pt.id LEFT JOIN users u ON p.last_user_id=u.id LEFT JOIN users creator ON p.created_by=creator.id LEFT JOIN power_categories pc ON p.category_id=pc.id LEFT JOIN locations l ON p.location_id=l.id WHERE p.id=?`, [req.params.id], (err, power) => {
    if (!power) { req.flash('error', 'غير موجود'); return res.redirect('/'); }
    db.all(`SELECT t.*, u.name as user_name FROM power_transactions t JOIN users u ON t.user_id=u.id WHERE t.power_id=? ORDER BY t.created_at DESC`, [req.params.id], (err, transactions) => {
      res.render('powers/view', { title: 'عرض التوكيل', power, transactions: transactions||[] });
    });
  });
});

router.get('/:id/edit', isAuthenticated, isAdmin, (req, res) => {
  db.get('SELECT * FROM powers WHERE id=?', [req.params.id], (err, power) => {
    if (!power) return res.redirect('/');
    db.all('SELECT * FROM power_types ORDER BY name', [], (err, types) => {
      db.all('SELECT * FROM power_categories ORDER BY name', [], (err, categories) => {
        db.all('SELECT * FROM locations ORDER BY name', [], (err, locations) => {
          res.render('powers/edit', { title: 'تعديل توكيل', power, types: types||[], categories: categories||[], locations: locations||[] });
        });
      });
    });
  });
});

router.post('/:id/edit', isAuthenticated, isAdmin, upload.single('pdf_file'), (req, res) => {
  const { client_name, archive_number, type_id, category_id, category, status, location_id, location, notes } = req.body;
  const pdf = req.file ? '/uploads/powers/' + req.file.filename : req.body.old_pdf;
  db.run(`UPDATE powers SET client_name=?, archive_number=?, type_id=?, category_id=?, category=?, status=?, location_id=?, location=?, pdf_file=?, notes=? WHERE id=?`,
    [client_name, archive_number, type_id, category_id, category, status, location_id, location, pdf, notes, req.params.id], (err) => {
      if (err) req.flash('error', 'خطأ');
      else { req.flash('success', 'تم التحديث'); db.run(`INSERT INTO activity_logs (user_id, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?)`, [req.session.user.id, 'تعديل توكيل', 'power', req.params.id, client_name]); }
      res.redirect('/powers/' + req.params.id);
    });
});

router.post('/:id/delete', isAuthenticated, isAdmin, (req, res) => {
  db.get('SELECT client_name FROM powers WHERE id=?', [req.params.id], (err, power) => {
    if (power) {
      db.run('DELETE FROM powers WHERE id=?', [req.params.id], (err) => {
        if (err) req.flash('error', 'لا يمكن الحذف');
        else { req.flash('success', 'تم الحذف'); db.run(`INSERT INTO activity_logs (user_id, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?)`, [req.session.user.id, 'حذف توكيل', 'power', req.params.id, power.client_name]); }
        res.redirect('/admin/all-powers');
      });
    } else res.redirect('/admin/all-powers');
  });
});

module.exports = router;
