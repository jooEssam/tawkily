const express = require('express');
const router = express.Router();
const db = require('../database');
const { isAuthenticated, isAdmin } = require('../middleware/auth');

router.get('/', isAuthenticated, isAdmin, (req, res) => {
  const { from_date, to_date, lawyer_id } = req.query;
  let q = `SELECT p.*, pt.name as type_name, u.name as last_user_name, pc.name as category_name FROM powers p LEFT JOIN power_types pt ON p.type_id=pt.id LEFT JOIN users u ON p.last_user_id=u.id LEFT JOIN power_categories pc ON p.category_id=pc.id WHERE 1=1`;
  let params = [];
  if (from_date) { q += ' AND date(p.created_at)>=?'; params.push(from_date); }
  if (to_date) { q += ' AND date(p.created_at)<=?'; params.push(to_date); }
  if (lawyer_id) { q += ' AND p.last_user_id=?'; params.push(lawyer_id); }
  q += ' ORDER BY p.created_at DESC';
  db.all(q, params, (err, powers) => {
    db.all('SELECT * FROM users WHERE role="lawyer" ORDER BY name', [], (err, lawyers) => {
      db.all(`SELECT u.name, COUNT(DISTINCT CASE WHEN p.status='مع زميل' AND p.last_user_id=u.id THEN p.id END) as current, COUNT(DISTINCT CASE WHEN t.action='سحب' THEN t.id END) as total_checkouts, COUNT(DISTINCT CASE WHEN t.action='إرجاع' THEN t.id END) as total_returns FROM users u LEFT JOIN powers p ON u.id=p.last_user_id LEFT JOIN power_transactions t ON u.id=t.user_id WHERE u.role='lawyer' GROUP BY u.id`, [], (err, lawyerStats) => {
        res.render('reports/index', { title: 'التقارير', powers: powers||[], lawyers: lawyers||[], lawyerStats: lawyerStats||[], query: req.query });
      });
    });
  });
});

module.exports = router;
