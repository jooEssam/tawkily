const express = require('express');
const router = express.Router();
const db = require('../database');
const { isAuthenticated } = require('../middleware/auth');

router.get('/', isAuthenticated, (req, res) => {
  db.all('SELECT * FROM notifications WHERE user_id=? OR user_id IS NULL ORDER BY created_at DESC LIMIT 50', [req.session.user.id], (err, notifications) => {
    res.render('reports/notifications', { title: 'الإشعارات', notifications: notifications||[] });
  });
});

router.post('/:id/read', isAuthenticated, (req, res) => {
  db.run('UPDATE notifications SET read=1 WHERE id=?', [req.params.id], (err) => res.json({ success: true }));
});

router.get('/api/unread', isAuthenticated, (req, res) => {
  db.get('SELECT COUNT(*) as c FROM notifications WHERE (user_id=? OR user_id IS NULL) AND read=0', [req.session.user.id], (err, row) => {
    res.json({ count: row ? row.c : 0 });
  });
});

module.exports = router;
