const express = require('express');
const router = express.Router();
const XLSX = require('xlsx');
const path = require('path');
const fs = require('fs');
const db = require('../database');
const { isAuthenticated, isAdmin } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', isAuthenticated, isAdmin, (req, res) => {
  res.render('import/index', { title: 'استيراد / تصدير' });
});

router.get('/template', isAuthenticated, isAdmin, (req, res) => {
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet([
    ['اسم الموكل', 'رقم الفهرس', 'نوع التوكيل', 'التصنيف', 'مكان الحفظ', 'ملاحظات'],
    ['محمدأحمد', 'F-001', 'بيع', 'حفظ', 'دولاب1-درج1', ''],
    ['عليخالد', 'F-002', 'شراء', 'متداول', 'دولاب2-درج1', 'توكيل عاجل']
  ]);
  XLSX.utils.book_append_sheet(wb, ws, 'نموذج التوكيلات');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', 'attachment; filename="tokili_template.xlsx"');
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

router.post('/import', isAuthenticated, isAdmin, upload.single('excel_file'), (req, res) => {
  if (!req.file) { req.flash('error', 'لم يتم رفع ملف'); return res.redirect('/import-export'); }
  const pdfFolder = req.body.pdf_folder || '';
  const wb = XLSX.readFile(req.file.path);
  const ws = wb.Sheets[wb.SheetNames[0]];
  const data = XLSX.utils.sheet_to_json(ws, { header: 1 });
  let imported = 0, errors = 0, pdfMatched = 0;

  function processRow(i) {
    if (i >= data.length) {
      req.flash('success', `تم استيراد ${imported} توكيل (${errors} خطأ) - ${pdfMatched} PDF مُطابق`);
      return res.redirect('/admin/all-powers');
    }
    const row = data[i];
    if (!row || !row[0] || !row[1]) { errors++; return processRow(i + 1); }

    const client_name = String(row[0]).trim();
    const archive_number = String(row[1]).trim();
    const type_name = row[2] ? String(row[2]).trim() : 'بيع';
    const category = row[3] ? String(row[3]).trim() : 'حفظ';
    const location = row[4] ? String(row[4]).trim() : '';
    const notes = row[5] ? String(row[5]).trim() : '';

    // Try to match PDF - remove spaces from client name
    const clientNoSpaces = client_name.replace(/\s+/g, '');
    let pdfPath = null;
    if (pdfFolder) {
      const possibleNames = [
        clientNoSpaces + '.pdf',
        clientNoSpaces + '.PDF',
        client_name + '.pdf',
        client_name + '.PDF'
      ];
      for (const name of possibleNames) {
        const fullPath = path.join(pdfFolder, name);
        if (fs.existsSync(fullPath)) {
          const destName = 'power-' + Date.now() + '-' + Math.round(Math.random()*1E9) + '.pdf';
          const destPath = path.join('./public/uploads/powers', destName);
          fs.copyFileSync(fullPath, destPath);
          pdfPath = '/uploads/powers/' + destName;
          pdfMatched++;
          break;
        }
      }
    }

    db.get('SELECT id FROM power_types WHERE name=?', [type_name], (err, typeRow) => {
      const type_id = typeRow ? typeRow.id : 1;
      db.get('SELECT id FROM locations WHERE name=?', [location], (err, locRow) => {
        const location_id = locRow ? locRow.id : null;
        db.run(`INSERT OR IGNORE INTO powers (client_name, archive_number, type_id, category, location_id, location, pdf_file, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [client_name, archive_number, type_id, category, location_id, location, pdfPath, notes, req.session.user.id], function(err) {
            if (!err) imported++;
            else errors++;
            processRow(i + 1);
          });
      });
    });
  }

  processRow(1); // Skip header
});

router.post('/export', isAuthenticated, isAdmin, (req, res) => {
  const { ids } = req.body;
  if (!ids || ids.length === 0) { req.flash('error', 'لم يتم اختيار توكيلات'); return res.redirect('/admin/all-powers'); }
  const placeholders = Array.isArray(ids) ? ids.map(() => '?').join(',') : '?';
  const idArray = Array.isArray(ids) ? ids : [ids];
  db.all(`SELECT p.*, pt.name as type_name, u.name as last_user_name, pc.name as category_name FROM powers p LEFT JOIN power_types pt ON p.type_id=pt.id LEFT JOIN users u ON p.last_user_id=u.id LEFT JOIN power_categories pc ON p.category_id=pc.id WHERE p.id IN (${placeholders})`, idArray, (err, powers) => {
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet([
      ['ID', 'اسم الموكل', 'رقم الفهرس', 'نوع التوكيل', 'التصنيف', 'الحالة', 'المكان', 'آخر مستخدم', 'تاريخ الإنشاء'],
      ...powers.map(p => [p.id, p.client_name, p.archive_number, p.type_name, p.category_name || p.category, p.status, p.location, p.last_user_name, p.created_at])
    ]);
    XLSX.utils.book_append_sheet(wb, ws, 'التوكيلات');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Disposition', 'attachment; filename="tokili_export.xlsx"');
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buf);
  });
});

module.exports = router;
