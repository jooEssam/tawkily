const express = require('express');
const router = express.Router();
const db = require('../database');
const { isAuthenticated, isLawyer } = require('../middleware/auth');

router.get('/dashboard', isAuthenticated, isLawyer, (req, res) => {
  const uid = req.session.user.id;
  db.get('SELECT COUNT(*) as c FROM powers WHERE last_user_id=? AND status="مع زميل"', [uid], (err, row) => {
    const currentPowers = row ? row.c : 0;
    db.get('SELECT COUNT(*) as c FROM power_transactions WHERE user_id=? AND action="سحب"', [uid], (err, row) => {
      const totalCheckouts = row ? row.c : 0;
      db.get('SELECT COUNT(*) as c FROM power_transactions WHERE user_id=? AND action="إرجاع"', [uid], (err, row) => {
        const totalReturns = row ? row.c : 0;
        db.all(`SELECT p.*, pt.name as type_name, t.checkout_at, julianday('now')-julianday(t.checkout_at) as days FROM powers p JOIN power_transactions t ON p.id=t.power_id JOIN power_types pt ON p.type_id=pt.id WHERE p.last_user_id=? AND p.status='مع زميل' AND t.return_at IS NULL ORDER BY t.checkout_at DESC`, [uid], (err, myPowers) => {
          db.all(`SELECT p.client_name, p.archive_number, pt.name as type_name, t.action, t.checkout_at, t.return_at, t.created_at, julianday('now')-julianday(t.checkout_at) as days FROM power_transactions t JOIN powers p ON t.power_id=p.id JOIN power_types pt ON p.type_id=pt.id WHERE t.user_id=? ORDER BY t.created_at DESC LIMIT 20`, [uid], (err, history) => {
            db.all(`SELECT a.*, p.client_name, p.archive_number FROM admin_alerts a JOIN powers p ON a.power_id=p.id WHERE a.user_id=? ORDER BY a.created_at DESC LIMIT 10`, [uid], (err, alerts) => {
              res.render('lawyer/dashboard', { title: 'لوحة تحكم المحامي', stats: { currentPowers, totalCheckouts, totalReturns }, myPowers: myPowers||[], history: history||[], alerts: alerts||[] });
            });
          });
        });
      });
    });
  });
});

router.get('/my-powers', isAuthenticated, isLawyer, (req, res) => {
  const uid = req.session.user.id;
  db.all(`SELECT p.*, pt.name as type_name, t.checkout_at, julianday('now')-julianday(t.checkout_at) as days FROM powers p JOIN power_transactions t ON p.id=t.power_id JOIN power_types pt ON p.type_id=pt.id WHERE p.last_user_id=? AND p.status='مع زميل' AND t.return_at IS NULL ORDER BY t.checkout_at DESC`, [uid], (err, powers) => {
    res.render('lawyer/my-powers', { title: 'توكيلاتي', powers: powers||[] });
  });
});

router.get('/my-history', isAuthenticated, isLawyer, (req, res) => {
  const uid = req.session.user.id;
  db.all(`SELECT p.client_name, p.archive_number, pt.name as type_name, t.action, t.checkout_at, t.return_at, t.created_at, julianday('now')-julianday(t.checkout_at) as days, t.days_held FROM power_transactions t JOIN powers p ON t.power_id=p.id JOIN power_types pt ON p.type_id=pt.id WHERE t.user_id=? ORDER BY t.created_at DESC`, [uid], (err, history) => {
    res.render('lawyer/my-history', { title: 'سجل استخدامي', history: history||[] });
  });
});

module.exports = router;
