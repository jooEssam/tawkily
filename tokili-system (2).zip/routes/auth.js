const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../database');
const { isAuthenticated } = require('../middleware/auth');

router.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/');
  res.render('auth/login', { title: 'تسجيل الدخول', layout: false });
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  db.get('SELECT * FROM users WHERE email = ?', [email], (err, user) => {
    if (err || !user) {
      req.flash('error', 'البريد أو كلمة المرور غير صحيحة');
      return res.redirect('/login');
    }
    if (user.status !== 'active') {
      req.flash('error', 'الحساب غير نشط');
      return res.redirect('/login');
    }
    if (!bcrypt.compareSync(password, user.password)) {
      req.flash('error', 'البريد أو كلمة المرور غير صحيحة');
      return res.redirect('/login');
    }
    req.session.user = { id: user.id, name: user.name, email: user.email, role: user.role };
    db.run(`INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)`,
      [user.id, 'تسجيل دخول', 'دخول للنظام', req.socket.remoteAddress]);
    req.flash('success', 'مرحباً ' + user.name);
    res.redirect('/');
  });
});

router.get('/logout', isAuthenticated, (req, res) => {
  const uid = req.session.user.id;
  req.session.destroy(() => {
    db.run(`INSERT INTO activity_logs (user_id, action, details) VALUES (?, ?, ?)`,
      [uid, 'تسجيل خروج', 'خروج من النظام']);
    res.redirect('/login');
  });
});

module.exports = router;
