const express = require('express');
const router = express.Router();
const db = require('../database');
const { isAuthenticated } = require('../middleware/auth');

router.post('/checkout/:powerId', isAuthenticated, (req, res) => {
  const uid = req.session.user.id;
  const pid = req.params.powerId;
  db.get('SELECT * FROM powers WHERE id=?', [pid], (err, power) => {
    if (!power || power.status !== 'متاح') { req.flash('error', 'غير متاح'); return res.redirect('back'); }
    db.run("UPDATE powers SET status='مع زميل', last_user_id=?, last_used_at=CURRENT_TIMESTAMP WHERE id=?", [uid, pid], (err) => {
      if (err) { req.flash('error', 'خطأ'); return res.redirect('back'); }
      db.run(`INSERT INTO power_transactions (power_id, user_id, action, checkout_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)`, [pid, uid, 'سحب'], (err) => {
        req.flash('success', 'تم السحب');
        db.run(`INSERT INTO activity_logs (user_id, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?)`, [uid, 'سحب توكيل', 'power', pid, power.client_name]);
        db.run(`INSERT INTO notifications (user_id, title, message, sound_type) VALUES (?, ?, ?, ?)`, [uid, 'تم الاستلام', `استلمت: ${power.client_name}`, 'checkout']);
        db.all('SELECT id FROM users WHERE role="admin"', [], (err, admins) => {
          admins.forEach(a => db.run(`INSERT INTO notifications (user_id, title, message, sound_type) VALUES (?, ?, ?, ?)`, [a.id, 'سحب توكيل', `${req.session.user.name} استلم ${power.client_name}`, 'checkout']));
        });
        res.redirect('back');
      });
    });
  });
});

router.post('/return/:powerId', isAuthenticated, (req, res) => {
  const uid = req.session.user.id;
  const pid = req.params.powerId;
  db.get('SELECT * FROM powers WHERE id=?', [pid], (err, power) => {
    if (!power || power.status !== 'مع زميل' || power.last_user_id != uid) { req.flash('error', 'لا يمكن الإرجاع'); return res.redirect('back'); }
    db.run("UPDATE powers SET status='متاح', last_used_at=CURRENT_TIMESTAMP WHERE id=?", [pid], (err) => {
      db.run(`UPDATE power_transactions SET return_at=CURRENT_TIMESTAMP, days_held=ROUND(julianday('now')-julianday(checkout_at)) WHERE power_id=? AND user_id=? AND return_at IS NULL`, [pid, uid], (err) => {
        req.flash('success', 'تم الإرجاع');
        db.run(`INSERT INTO activity_logs (user_id, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?)`, [uid, 'إرجاع توكيل', 'power', pid, power.client_name]);
        db.run(`INSERT INTO notifications (user_id, title, message, sound_type) VALUES (?, ?, ?, ?)`, [uid, 'تم الإرجاع', `أعدت: ${power.client_name}`, 'return']);
        db.all('SELECT id FROM users WHERE role="admin"', [], (err, admins) => {
          admins.forEach(a => db.run(`INSERT INTO notifications (user_id, title, message, sound_type) VALUES (?, ?, ?, ?)`, [a.id, 'إرجاع توكيل', `${req.session.user.name} أعاد ${power.client_name}`, 'return']));
        });
        res.redirect('back');
      });
    });
  });
});

module.exports = router;
