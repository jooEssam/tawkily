const db = require('../database');
const bcrypt = require('bcryptjs');
const UserController = {
  getAllLawyers: (cb) => db.all('SELECT * FROM users WHERE role="lawyer" ORDER BY created_at DESC', [], cb),
  getById: (id, cb) => db.get('SELECT * FROM users WHERE id=?', [id], cb),
  create: (data, cb) => { const h = bcrypt.hashSync(data.password, 10); db.run('INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, ?)', [data.name, data.email, h, data.phone, 'lawyer'], cb); },
  update: (id, data, cb) => db.run('UPDATE users SET name=?, email=?, phone=?, status=? WHERE id=?', [data.name, data.email, data.phone, data.status, id], cb),
  delete: (id, cb) => db.run('DELETE FROM users WHERE id=? AND role="lawyer"', [id], cb)
};
module.exports = UserController;