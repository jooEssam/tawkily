const db = require('../database');
const PowerController = {
  getAll: (cb) => db.all(`SELECT p.*, pt.name as type_name, u.name as last_user_name, pc.name as category_name, l.name as location_name FROM powers p LEFT JOIN power_types pt ON p.type_id=pt.id LEFT JOIN users u ON p.last_user_id=u.id LEFT JOIN power_categories pc ON p.category_id=pc.id LEFT JOIN locations l ON p.location_id=l.id ORDER BY p.created_at DESC`, [], cb),
  getById: (id, cb) => db.get(`SELECT p.*, pt.name as type_name, u.name as last_user_name, creator.name as creator_name, pc.name as category_name, l.name as location_name FROM powers p LEFT JOIN power_types pt ON p.type_id=pt.id LEFT JOIN users u ON p.last_user_id=u.id LEFT JOIN users creator ON p.created_by=creator.id LEFT JOIN power_categories pc ON p.category_id=pc.id LEFT JOIN locations l ON p.location_id=l.id WHERE p.id=?`, [id], cb),
  create: (data, cb) => db.run(`INSERT INTO powers (client_name, archive_number, type_id, category_id, category, location_id, location, pdf_file, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [data.client_name, data.archive_number, data.type_id, data.category_id, data.category, data.location_id, data.location, data.pdf_file, data.notes, data.created_by], cb),
  update: (id, data, cb) => db.run(`UPDATE powers SET client_name=?, archive_number=?, type_id=?, category_id=?, category=?, status=?, location_id=?, location=?, pdf_file=?, notes=? WHERE id=?`, [data.client_name, data.archive_number, data.type_id, data.category_id, data.category, data.status, data.location_id, data.location, data.pdf_file, data.notes, id], cb),
  delete: (id, cb) => db.run('DELETE FROM powers WHERE id=?', [id], cb),
  checkout: (pid, uid, cb) => db.run("UPDATE powers SET status='مع زميل', last_user_id=?, last_used_at=CURRENT_TIMESTAMP WHERE id=?", [uid, pid], cb),
  return: (pid, cb) => db.run("UPDATE powers SET status='متاح', last_used_at=CURRENT_TIMESTAMP WHERE id=?", [pid], cb)
};
module.exports = PowerController;