const db = require('../database');
const TransactionController = {
  create: (data, cb) => db.run(`INSERT INTO power_transactions (power_id, user_id, action, checkout_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)`, [data.power_id, data.user_id, data.action], cb),
  returnPower: (pid, uid, cb) => db.run(`UPDATE power_transactions SET return_at=CURRENT_TIMESTAMP, days_held=ROUND(julianday('now')-julianday(checkout_at)) WHERE power_id=? AND user_id=? AND return_at IS NULL`, [pid, uid], cb),
  getByPowerId: (pid, cb) => db.all(`SELECT t.*, u.name as user_name FROM power_transactions t JOIN users u ON t.user_id=u.id WHERE t.power_id=? ORDER BY t.created_at DESC`, [pid], cb),
  getByUserId: (uid, cb) => db.all(`SELECT t.*, p.client_name, p.archive_number, pt.name as type_name FROM power_transactions t JOIN powers p ON t.power_id=p.id JOIN power_types pt ON p.type_id=pt.id WHERE t.user_id=? ORDER BY t.created_at DESC`, [uid], cb)
};
module.exports = TransactionController;