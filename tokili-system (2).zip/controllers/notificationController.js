const db = require('../database');
const NotificationController = {
  create: (data, cb) => db.run(`INSERT INTO notifications (user_id, title, message, sound_type) VALUES (?, ?, ?, ?)`, [data.user_id, data.title, data.message, data.sound_type || 'notification'], cb),
  getByUserId: (uid, cb) => db.all('SELECT * FROM notifications WHERE user_id=? OR user_id IS NULL ORDER BY created_at DESC LIMIT 50', [uid], cb),
  markAsRead: (id, cb) => db.run('UPDATE notifications SET read=1 WHERE id=?', [id], cb),
  getUnreadCount: (uid, cb) => db.get('SELECT COUNT(*) as c FROM notifications WHERE (user_id=? OR user_id IS NULL) AND read=0', [uid], cb),
  createForAllLawyers: (title, msg, sound, cb) => { db.all('SELECT id FROM users WHERE role="lawyer" AND status="active"', [], (err, lawyers) => { if (err) return cb(err); lawyers.forEach(l => db.run(`INSERT INTO notifications (user_id, title, message, sound_type) VALUES (?, ?, ?, ?)`, [l.id, title, msg, sound || 'notification'])); cb(null); }); }
};
module.exports = NotificationController;