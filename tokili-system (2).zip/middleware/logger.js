const db = require('../database');
const logActivity = (action, target_type, target_id, details) => {
  return (req, res, next) => {
    const userId = req.session.user ? req.session.user.id : null;
    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || null;
    db.run(
      `INSERT INTO activity_logs (user_id, action, target_type, target_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)`,
      [userId, action, target_type, target_id || null, details || null, ip],
      (err) => { if (err) console.error('Logger error:', err.message); }
    );
    next();
  };
};
module.exports = { logActivity };
