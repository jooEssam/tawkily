const isAuthenticated = (req, res, next) => {
  if (req.session.user) return next();
  req.flash('error', 'يجب تسجيل الدخول أولاً');
  res.redirect('/login');
};
const isAdmin = (req, res, next) => {
  if (req.session.user && req.session.user.role === 'admin') return next();
  req.flash('error', 'ليس لديك صلاحية الوصول');
  res.redirect('/');
};
const isLawyer = (req, res, next) => {
  if (req.session.user && req.session.user.role === 'lawyer') return next();
  req.flash('error', 'ليس لديك صلاحية الوصول');
  res.redirect('/');
};
module.exports = { isAuthenticated, isAdmin, isLawyer };
